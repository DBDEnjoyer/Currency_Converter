package com.example.currency;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class ExchangeRateService {

    private static final String API_TEMPLATE = "https://open.er-api.com/v6/latest/%s";
    private static final Duration TIMEOUT = Duration.ofSeconds(15);
    private static final Duration CACHE_TTL = Duration.ofHours(12);
    private static final Gson GSON = new Gson();

    private final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(TIMEOUT)
            .build();

    private final Path cacheDir;

    public ExchangeRateService(Path cacheDir) {
        this.cacheDir = cacheDir;
        try {
            Files.createDirectories(cacheDir);
        } catch (IOException ignored) { }
    }

    public Map<String, BigDecimal> getRates(String base) throws IOException, InterruptedException {
        base = base.toUpperCase().trim();
        Path cacheFile = cacheDir.resolve("rates_" + base + ".json");

        if (Files.exists(cacheFile)) {
            try (InputStream in = Files.newInputStream(cacheFile)) {
                String json = new String(in.readAllBytes());
                Map<String, BigDecimal> cached = parseRates(json);
                if (!cached.isEmpty()) {
                    JsonObject obj = GSON.fromJson(json, JsonObject.class);
                    long ts = obj.has("time_last_update_unix") ? obj.get("time_last_update_unix").getAsLong() : 0L;
                    if (Instant.ofEpochSecond(ts).plus(CACHE_TTL).isAfter(Instant.now())) {
                        return cached;
                    }
                }
            } catch (Exception ignored) { }
        }

        String url = API_TEMPLATE.formatted(base);
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .timeout(TIMEOUT)
                .GET()
                .build();

        HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() == 200) {
            String body = resp.body();
            Map<String, BigDecimal> parsed = parseRates(body);
            if (!parsed.isEmpty()) {
                try (OutputStream out = Files.newOutputStream(cacheFile)) {
                    out.write(body.getBytes());
                } catch (Exception ignored) { }
                return parsed;
            }
        }

        if (Files.exists(cacheFile)) {
            try (InputStream in = Files.newInputStream(cacheFile)) {
                String json = new String(in.readAllBytes());
                Map<String, BigDecimal> cached = parseRates(json);
                if (!cached.isEmpty()) return cached;
            } catch (Exception ignored) { }
        }

        return Collections.emptyMap();
    }

    private Map<String, BigDecimal> parseRates(String json) {
        try {
            JsonObject root = GSON.fromJson(json, JsonObject.class);
            if (!root.has("result") || !"success".equals(root.get("result").getAsString())) {
                return Collections.emptyMap();
            }
            JsonObject rates = root.getAsJsonObject("rates");
            Map<String, BigDecimal> map = new HashMap<>();
            for (String key : rates.keySet()) {
                map.put(key.toUpperCase(), rates.get(key).getAsBigDecimal());
            }
            return map;
        } catch (Exception e) {
            return Collections.emptyMap();
        }
    }
}

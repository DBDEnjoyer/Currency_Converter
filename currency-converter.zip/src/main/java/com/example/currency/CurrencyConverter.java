package com.example.currency;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Path;
import java.util.*;

public class CurrencyConverter {

    private static final int SCALE = 6; // Nachkommastellen

    public static void main(String[] args) {
        System.out.println("=== Währungsrechner (Live-Raten mit Cache) ===");
        System.out.println("Tipps: Kürzel wie EUR, USD, CHF, GBP, JPY …");
        System.out.println("Beispiel: 100 EUR -> USD");
        System.out.println();

        Scanner sc = new Scanner(System.in);
        ExchangeRateService service = new ExchangeRateService(Path.of(System.getProperty("user.home"), ".currency-cache"));

        while (true) {
            try {
                System.out.print("Betrag (oder 'exit'): ");
                String amountStr = sc.next();
                if (amountStr.equalsIgnoreCase("exit")) break;

                BigDecimal amount = new BigDecimal(amountStr);

                System.out.print("Von Währung (z.B. EUR): ");
                String from = sc.next().toUpperCase(Locale.ROOT).trim();

                System.out.print("Nach Währung (z.B. USD): ");
                String to = sc.next().toUpperCase(Locale.ROOT).trim();

                var rates = service.getRates(from);
                if (!rates.containsKey(to)) {
                    System.out.println("Unbekanntes Ziel-Kürzel '" + to + "'.");
                    continue;
                }

                BigDecimal rate = rates.get(to);
                BigDecimal result = amount.multiply(rate).setScale(SCALE, RoundingMode.HALF_UP);

                System.out.printf(Locale.ROOT, "%s %s = %s %s  (Kurs %s->%s = %s)%n",
                        amount.stripTrailingZeros().toPlainString(), from,
                        result.stripTrailingZeros().toPlainString(), to,
                        from, to, rate.stripTrailingZeros().toPlainString());

                System.out.println();
            } catch (Exception e) {
                System.out.println("Eingabe ungültig. Bitte nochmal versuchen. (" + e.getMessage() + ")");
                sc.nextLine(); // Puffer leeren
            }
        }

        System.out.println("Tschüss!");
    }
}
